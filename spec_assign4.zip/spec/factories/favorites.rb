FactoryBot.define do
  factory :favorite do
    book
    user
  end
end
